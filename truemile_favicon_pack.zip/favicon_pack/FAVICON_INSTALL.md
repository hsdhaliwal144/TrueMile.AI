# TrueMile favicon — installation

## What this fixes

Right now `truemile.ai` shows a generic circle in browser tabs. After installing
these files, your tab will show the TrueMile route mark — both in browsers and
when shared as a link (iMessage, Slack, Twitter).

## Step 1 — Upload these files to your web root

Upload to the root of your site (same level as `index.html`):

```
/favicon.ico
/favicon-16x16.png
/favicon-32x32.png
/apple-touch-icon.png
/android-chrome-192x192.png
/android-chrome-512x512.png
/site.webmanifest
```

On Vercel: drop them into your `public/` folder.
On Netlify: drop them into your root or `public/` folder.
On Railway / custom: place them at the document root.

## Step 2 — Add these lines to your <head>

Inside the `<head>` of every page (or your root layout):

```html
<link rel="icon" type="image/x-icon" href="/favicon.ico">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
<link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
<link rel="manifest" href="/site.webmanifest">
<meta name="theme-color" content="#E8501E">
```

## Step 3 — Fix iMessage / Slack link previews

For the link preview that showed up in your iMessage screenshot (currently
shows a generic compass icon), you also need Open Graph tags. Add these to
your `<head>`:

```html
<meta property="og:title" content="TrueMile">
<meta property="og:description" content="Agentic optimization for mid-market trucking. Plan the week. Adapt in real time. Turn idle time into revenue.">
<meta property="og:image" content="https://truemile.ai/og-image.png">
<meta property="og:url" content="https://truemile.ai">
<meta property="og:type" content="website">

<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="TrueMile">
<meta name="twitter:description" content="Agentic optimization for mid-market trucking.">
<meta name="twitter:image" content="https://truemile.ai/og-image.png">
```

You'll need to create `og-image.png` — a 1200×630 image with the TrueMile
logo and tagline on charcoal background. Send a request if you want one
generated.

## Step 4 — Verify

After deploying:
1. Visit `truemile.ai` — tab should show the orange route mark
2. Visit `truemile.ai/favicon.ico` directly — should download/display the icon
3. Send `truemile.ai` in iMessage — the link preview should update (may take
   24-48 hours to recache; force refresh via apple-touch-icon.png)
4. Add the site to iPhone home screen — should show the orange icon

## Why the iMessage preview shows a compass right now

iMessage uses Safari's default icon when no `apple-touch-icon` is found. Once
you upload `apple-touch-icon.png` and add the `<link rel="apple-touch-icon">`
tag, iOS will use your logo. Apple caches aggressively — give it 24-48 hours
or test by typing the URL fresh into iMessage from a different conversation.

## Caching note

Browsers cache favicons hard. To force a refresh during development:
- Visit `truemile.ai/favicon.ico?v=2` in a new tab
- Or hard refresh the homepage (Cmd+Shift+R / Ctrl+Shift+R)
- iMessage previews can take 24-48 hours; not a fast cycle for testing
